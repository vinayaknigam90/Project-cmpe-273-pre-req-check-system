#Lib to support database function
