# CarbonGlue

Abstract

Building a pre-requisite check system using machine learning OpenCV tool.

Requirements:

1. Upload the sample data or template with fields to be extracted.

2. Capture with screenshot using a solution like html2canvas

3. Send the submission confirmation email and store the data into database.
